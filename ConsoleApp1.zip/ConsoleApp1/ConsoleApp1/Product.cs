﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public enum color
    {
        Red,Green,Blue,Pink
    }
    public enum size
    {
        small,medium,large
    }
    public class Product
    {
       public string Name { get; set; }
        public color Color { get; set; }
        public size Size { get; set; }

        public Product(string Name,color color1,size size1)
        {
            this.Name = Name;
            Color = color1;
            Size = size1;
        }

    }
    public interface ISpecification
    {
        bool isSatisfied(Product p);
    }
    //class ColorSpeciofiation : ISpecification
    //{
    //    private color Color;
    //    public ColorSpeciofiation(color Color)
    //    {

    //    }
    //    //public bool isSatisfied(Product p)
    //    //{
           
    //    //}
    //}
}
