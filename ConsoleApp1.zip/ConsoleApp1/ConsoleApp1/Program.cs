﻿using System;


namespace ConsoleApp1
{
    class A
    {
        public static int count;
        public int i;
        private int j;
        
        static A()
        {
            count = 0;
        }
        public A()
        {
            Console.WriteLine("Enter values");
            i = Convert.ToInt32(Console.ReadLine());
            j = Convert.ToInt32(Console.ReadLine());
        }
        public A(int i,int j)
        {
            this.i = i;
            this.j = j;
        }
        public void display()
        {
            Console.WriteLine("i="+i);
            Console.WriteLine("j=" + j);
            Console.WriteLine(count);
            Console.WriteLine("--------------");

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //var apple = new Product("Apple", color.Green, size.small);
            //var tree = new Product("Tree", color.Green, size.large);
            //var house = new Product("House", color.Blue, size.medium);

            //Product[] products = { apple, tree, house };
            //Console.WriteLine("Green Products:");
            A obj = new A();
            A obj1 = new A();
            
            A.count = A.count + 1;
            obj.display();
            obj1.display();
                
            Console.ReadLine();


        }
    }
}
