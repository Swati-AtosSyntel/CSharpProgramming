﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class ProductFilter
    {
        //public Product[] filterByColor(Product [] prds,color color1)
        //{
        //    Product[] temp=new Product[5];
        //    int i = 0;
        //    foreach (var p in prds)
        //    {
                
        //        if (p.Color == color1)
        //        {
        //            temp[i] = p;
                    
        //        }
        //        continue;
        //    }
        //    return temp;
        //}
    }
}
